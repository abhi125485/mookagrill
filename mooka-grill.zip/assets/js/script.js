// JS file placeholder
console.log("Mooka Grill site loaded");